Enclosed are four numpy arrays, with data for light curves of a specific caustic crossing.

The model simulated is image C from QSO 2237+0305. 100% of the mass is calculated as stars.
The starfield calculated is of size 393x393 uarcsecs, traced by 10000x10000 rays.
The magnification map is of size 98x98 uarcsecs, at the center of the starfield.

The four light curves come from four different quasar sizes. They model quasars of:
- 5 gravitational radii
- 10 gravitational radii
- 20 gravitational radii
- 40 gravitational radii

where the mass of the supermassive black hole is set as 1 billion solar masses.


TO OPEN THE FILES:

start up a python REPL and run the following commands:

>>> import numpy as np
>>> data = np.load(FILENAME IN QUOTES)
>>> x = data['xAxis']
>>> y = data['yAxis']

x now represents distance from the start of the light curve. y now represents the magnification coefficent at that point. 
To go to magnitude, the easiest would be with 

>>> y = -2.5*np.log10(y)

To plot, I would recommend the following:

>>> from matplotlib import pyplot as pl
>>> pl.plot(x,y,label=str(Quasar SIZE))
>>> pl.legend()
>>> pl.show()

If you have any questions let me know! 

Jordan
